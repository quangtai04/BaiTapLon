package data;

import java.util.ArrayList;

public class TowerCannonBlue extends Tower{
         public  TowerCannonBlue(TowerType type,Tile startTile,ArrayList<Enemy> enemies) {
        	 super(type,startTile,enemies);
         }
         
}
