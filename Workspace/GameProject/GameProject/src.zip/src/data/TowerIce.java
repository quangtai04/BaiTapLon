package data;

public class TowerIce {

}
